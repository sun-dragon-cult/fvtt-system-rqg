export const registerSettings = function () {
    // Register any custom system settings here
    console.log('*** RegisterSettings js *** DEBUG', game.settings);
    game.settings.register("rqg", "macroShorthand", {
        name: "Shortened Macro Syntax",
        hint: "Enable a shortened macro syntax which allows referencing attributes directly, for example @str instead of @attributes.str.value. Disable this setting if you need the ability to reference the full attribute model, for example @attributes.str.label.",
        scope: "world",
        type: Boolean,
        default: false,
        config: false
    });
};
