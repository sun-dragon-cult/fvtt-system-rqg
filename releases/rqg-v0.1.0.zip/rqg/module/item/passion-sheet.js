import { passionType } from "../data-model/item-data/item-types.js";
import { PassionsEnum } from "../data-model/item-data/passion.js";
export class PassionSheet extends ItemSheet {
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["rqg", "sheet", passionType],
            template: "systems/rqg/module/item/passion-sheet.html",
            width: 520,
            height: 250,
        });
    }
    getData() {
        const data = super.getData();
        data.data.passionTypes = Object.keys(PassionsEnum);
        return data;
    }
}
