export class Tracked {
    constructor() {
        this.value = 0;
    }
}
export const emptyTracked = new Tracked();
