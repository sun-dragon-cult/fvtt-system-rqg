export class Tracked {
  value?: number = 0;
  max?: number;
}

export const emptyTracked = new Tracked();
