export class Ability {
    constructor(value = 0, experience) {
        this.value = value;
        this.experience = experience;
    }
}
export const emptyAbility = new Ability();
