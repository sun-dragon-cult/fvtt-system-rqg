import { emptyAttributes } from "./attributes.js";
import { emptyHumanoidCharacteristics } from "./characteristics.js";
import { basicElementalRunes } from "./elemental-runes.js";
import { basicPowerRunes } from "./power-runes.js";
import { RaceEnum } from "./race.js";
import { emptyHumanoidHitLocations } from "./hit-location.js";
import { emptyBackground } from "./background.js";
export class ActorDataRqg {
    constructor(characteristics, hitLocations, // Different races can have different hit locations
    attributes, elements, powers, background, race = RaceEnum.Humanoid) {
        this.characteristics = characteristics;
        this.hitLocations = hitLocations;
        this.attributes = attributes;
        this.elements = elements;
        this.powers = powers;
        this.background = background;
        this.race = race;
    }
    ;
}
export const emptyActorDataRqg = new ActorDataRqg(emptyHumanoidCharacteristics, emptyHumanoidHitLocations, emptyAttributes, basicElementalRunes, basicPowerRunes, emptyBackground);
