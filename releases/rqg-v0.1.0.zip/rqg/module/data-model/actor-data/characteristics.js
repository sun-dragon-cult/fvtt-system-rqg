import { Ability } from "../shared/ability.js";
export class Characteristics {
    constructor(strength, constitution, size, dexterity, intelligence, power, charisma) {
        this.strength = strength;
        this.constitution = constitution;
        this.size = size;
        this.dexterity = dexterity;
        this.intelligence = intelligence;
        this.power = power;
        this.charisma = charisma;
    }
    ;
}
// Check if experience exists to see if the Characteristic can be raised with experience (show checkbox)
const emptyExp = new Ability(0, false);
const emptyNoExp = new Ability();
export const emptyHumanoidCharacteristics = new Characteristics(emptyNoExp, emptyNoExp, emptyNoExp, emptyNoExp, emptyNoExp, emptyExp, emptyNoExp);
