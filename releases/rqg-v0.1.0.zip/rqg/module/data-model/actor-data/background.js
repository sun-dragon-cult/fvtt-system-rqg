export var OccupationEnum;
(function (OccupationEnum) {
    OccupationEnum["assistantShaman"] = "assistantShaman";
    OccupationEnum["bandit"] = "bandit";
    OccupationEnum["chariotDriver"] = "chariotDriver";
    OccupationEnum["crafter"] = "crafter";
    OccupationEnum["entertainer"] = "entertainer";
    OccupationEnum["farmer"] = "farmer";
    OccupationEnum["fisher"] = "fisher";
    OccupationEnum["healer"] = "healer";
    OccupationEnum["herder"] = "herder";
    OccupationEnum["hunter"] = "hunter";
    OccupationEnum["merchant"] = "merchant";
    OccupationEnum["noble"] = "noble";
    OccupationEnum["philosopher"] = "philosopher";
    OccupationEnum["priest"] = "priest";
    OccupationEnum["scribe"] = "scribe";
    OccupationEnum["thief"] = "thief";
    OccupationEnum["warriorHeavyInfantry"] = "warriorHeavyInfantry";
    OccupationEnum["warriorLightInfantry"] = "warriorLightInfantry";
    OccupationEnum["warriorHeavyCavalry"] = "warriorHeavyCavalry";
    OccupationEnum["warriorLightCavalry"] = "warriorLightCavalry";
})(OccupationEnum || (OccupationEnum = {}));
export var HomeLandEnum;
(function (HomeLandEnum) {
    HomeLandEnum["sartar"] = "sartar";
    HomeLandEnum["esrolia"] = "esrolia";
    HomeLandEnum["grazelands"] = "grazelands";
    HomeLandEnum["praxianTribes"] = "praxianTribes";
    HomeLandEnum["lunarTarsh"] = "lunarTarsh";
    HomeLandEnum["oldTarsh"] = "oldTarsh";
})(HomeLandEnum || (HomeLandEnum = {}));
export class Background {
    constructor(birthYear, age, gender, occupation, homeland, tribe, clan, reputation, standardOfLiving, ransom, baseIncome, biography) {
        this.birthYear = birthYear;
        this.age = age;
        this.gender = gender;
        this.occupation = occupation;
        this.homeland = homeland;
        this.tribe = tribe;
        this.clan = clan;
        this.reputation = reputation;
        this.standardOfLiving = standardOfLiving;
        this.ransom = ransom;
        this.baseIncome = baseIncome;
        this.biography = biography;
    }
    ;
}
export const emptyBackground = new Background();
