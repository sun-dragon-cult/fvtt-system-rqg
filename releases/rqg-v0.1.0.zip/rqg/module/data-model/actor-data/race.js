export var RaceEnum;
(function (RaceEnum) {
    RaceEnum["Humanoid"] = "humanoid";
    RaceEnum["WingedHumanoid"] = "winged-humanoid";
    RaceEnum["AnimalFourLegged"] = "animal-four-legged";
    RaceEnum["BirdFlying"] = "bird-flying";
    RaceEnum["BirdRunning"] = "bird-running";
    RaceEnum["Centaur"] = "centaur";
    RaceEnum["Dragon"] = "dragon";
    RaceEnum["DragonSnailOneHeaded"] = "dragon-snail-one-headed";
    RaceEnum["DragonSnailTwoHeaded"] = "dragon-snail-two-headed";
    RaceEnum["Beetle"] = "beetle";
})(RaceEnum || (RaceEnum = {}));
