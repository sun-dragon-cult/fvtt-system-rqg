import { Ability } from "../shared/ability.js";
export class PowerRunes {
    constructor(man, beast, fertility, death, harmony, disorder, truth, illusion, stasis, movement) {
        this.man = man;
        this.beast = beast;
        this.fertility = fertility;
        this.death = death;
        this.harmony = harmony;
        this.disorder = disorder;
        this.truth = truth;
        this.illusion = illusion;
        this.stasis = stasis;
        this.movement = movement;
    }
    ;
}
const emptyAbility = new Ability();
export const basicPowerRunes = new PowerRunes(emptyAbility, emptyAbility, emptyAbility, emptyAbility, emptyAbility, emptyAbility, emptyAbility, emptyAbility, emptyAbility, emptyAbility);
