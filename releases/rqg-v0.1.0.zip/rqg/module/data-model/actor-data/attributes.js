import { emptyTracked } from "../shared/tracked.js";
export class Attributes {
    constructor(magicPoints, hitPoints, healingRate, damageBonus, // For example "1D4"
    spiritCombatDamage, maximumEncumbrance, sizStrikeRank, dexStrikeRank) {
        this.magicPoints = magicPoints;
        this.hitPoints = hitPoints;
        this.healingRate = healingRate;
        this.damageBonus = damageBonus;
        this.spiritCombatDamage = spiritCombatDamage;
        this.maximumEncumbrance = maximumEncumbrance;
        this.sizStrikeRank = sizStrikeRank;
        this.dexStrikeRank = dexStrikeRank;
    }
    ;
}
export const emptyAttributes = new Attributes(emptyTracked, emptyTracked);
