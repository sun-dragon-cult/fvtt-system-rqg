import { emptyTracked } from "../shared/tracked.js";
export var HitLocationsEnum;
(function (HitLocationsEnum) {
    HitLocationsEnum["head"] = "head";
    HitLocationsEnum["leftArm"] = "leftArm";
    HitLocationsEnum["rightArm"] = "rightArm";
    HitLocationsEnum["chest"] = "chest";
    HitLocationsEnum["abdomen"] = "abdomen";
    HitLocationsEnum["leftLeg"] = "leftLeg";
    HitLocationsEnum["rightLeg"] = "rightLeg";
    HitLocationsEnum["leftWing"] = "leftWing";
    HitLocationsEnum["rightWing"] = "rightWing";
    HitLocationsEnum["tail"] = "tail";
    HitLocationsEnum["leftHindLeg"] = "leftHindLeg";
    HitLocationsEnum["rightHindLeg"] = "rightHindLeg";
    HitLocationsEnum["forequarter"] = "forequarter";
    HitLocationsEnum["hindquarter"] = "hindquarter";
    HitLocationsEnum["thorax"] = "thorax";
    HitLocationsEnum["leftForeLeg"] = "leftForeLeg";
    HitLocationsEnum["rightForeLeg"] = "rightForeLeg";
    HitLocationsEnum["shell"] = "shell";
    HitLocationsEnum["forebody"] = "forebody";
    HitLocationsEnum["leftHead"] = "leftHead";
    HitLocationsEnum["rightHead"] = "rightHead";
})(HitLocationsEnum || (HitLocationsEnum = {}));
export class HitLocations {
    constructor(// TODO Look through the order so that they become intuitive for all races!
    head, leftArm, rightArm, chest, abdomen, leftLeg, rightLeg, leftWing, rightWing) {
        this.head = head;
        this.leftArm = leftArm;
        this.rightArm = rightArm;
        this.chest = chest;
        this.abdomen = abdomen;
        this.leftLeg = leftLeg;
        this.rightLeg = rightLeg;
        this.leftWing = leftWing;
        this.rightWing = rightWing;
    }
    ;
}
export class HitLocation {
    constructor(dieFrom, dieTo, hp, wounds = [], ap = 0) {
        this.dieFrom = dieFrom;
        this.dieTo = dieTo;
        this.hp = hp;
        this.wounds = wounds;
        this.ap = ap;
    }
    ;
}
// TODO Make a map of hit locations per race! Are there more differences than hitlocations?
// TODO How to make this work? I guess we need constants that are 'compiled'?
// export function createHitLocations(race: RaceEnum): Array<HitLocation> {
//   if (race === RaceEnum.WingedHumanoid) { // TODO Just placeholder for future
//     return emptyHumanoidHitLocations;
//   } else {
//     return emptyHumanoidHitLocations; // Default to humanoid
//   }
// }
export const emptyHumanoidHitLocations = new HitLocations(new HitLocation(19, 20, emptyTracked), new HitLocation(16, 18, emptyTracked), new HitLocation(13, 15, emptyTracked), new HitLocation(12, 12, emptyTracked), new HitLocation(9, 11, emptyTracked), new HitLocation(5, 8, emptyTracked), new HitLocation(1, 4, emptyTracked), undefined, undefined);
// TODO Just getting a feel for creating other creatures...
export const emptyHumanoidWingedHitLocations = new HitLocations(new HitLocation(19, 20, emptyTracked), new HitLocation(17, 18, emptyTracked), new HitLocation(15, 16, emptyTracked), new HitLocation(10, 10, emptyTracked), new HitLocation(7, 9, emptyTracked), new HitLocation(4, 6, emptyTracked), new HitLocation(1, 3, emptyTracked), new HitLocation(13, 14, emptyTracked), new HitLocation(11, 12, emptyTracked));
