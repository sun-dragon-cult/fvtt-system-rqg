import { Ability } from "../shared/ability.js";
export class ElementalRunes {
    constructor(fire, darkness, water, earth, air, moon) {
        this.fire = fire;
        this.darkness = darkness;
        this.water = water;
        this.earth = earth;
        this.air = air;
        this.moon = moon;
    }
    ;
}
const emptyAbility = new Ability();
export const basicElementalRunes = new ElementalRunes(emptyAbility, emptyAbility, emptyAbility, emptyAbility, emptyAbility, emptyAbility);
