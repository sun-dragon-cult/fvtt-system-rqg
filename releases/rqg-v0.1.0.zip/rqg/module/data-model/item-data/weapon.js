import { emptyTracked } from "../shared/tracked.js";
export const emptyWeapon = {
    description: "",
    damage: "",
    strikeRank: 0,
    quantity: 1,
    encumbrance: 1,
    hitPoints: emptyTracked
    // TODO Required skill (to calculate % and total SR)
};
