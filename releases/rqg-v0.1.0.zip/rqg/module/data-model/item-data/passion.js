export var PassionsEnum;
(function (PassionsEnum) {
    PassionsEnum["Devotion"] = "devotion";
    PassionsEnum["Fear"] = "fear";
    PassionsEnum["Hate"] = "hate";
    PassionsEnum["Honor"] = "honor";
    PassionsEnum["Loyalty"] = "loyalty";
    PassionsEnum["Love"] = "love";
})(PassionsEnum || (PassionsEnum = {}));
export const emptyPassion = {
    passion: PassionsEnum.Love,
    description: "",
    value: 0,
    experience: false,
};
