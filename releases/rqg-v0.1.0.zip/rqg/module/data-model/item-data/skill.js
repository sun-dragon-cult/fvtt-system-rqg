export var SkillCategoryEnum;
(function (SkillCategoryEnum) {
    SkillCategoryEnum["Agility"] = "Agility";
    SkillCategoryEnum["Communication"] = "Communication";
    SkillCategoryEnum["Knowledge"] = "Knowledge";
    SkillCategoryEnum["Magic"] = "Magic";
    SkillCategoryEnum["Manipulation"] = "Manipulation";
    SkillCategoryEnum["Perception"] = "Perception";
    SkillCategoryEnum["Stealth"] = "Stealth";
    SkillCategoryEnum["MeleeWeapons"] = "MeleeWeapons";
    SkillCategoryEnum["MissileWeapons"] = "MissileWeapons";
    SkillCategoryEnum["Shields"] = "Shields";
    SkillCategoryEnum["NaturalWeapons"] = "NaturalWeapons";
    SkillCategoryEnum["OtherSkills"] = "OtherSkills";
})(SkillCategoryEnum || (SkillCategoryEnum = {}));
export const emptySkill = {
    category: SkillCategoryEnum.Agility,
    baseChance: 0,
    value: 0,
    experience: false
};
