export const skillType = "skill";
export const passionType = "passion";
export const weaponType = "weapon";
