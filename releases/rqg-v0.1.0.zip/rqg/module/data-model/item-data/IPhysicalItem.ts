export interface IPhysicalItem {
  quantity: number,
  encumbrance: number
}
